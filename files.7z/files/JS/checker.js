let  link = '/eh//sjifj/sanas'
const alu = link.split("/")
console.log(alu)